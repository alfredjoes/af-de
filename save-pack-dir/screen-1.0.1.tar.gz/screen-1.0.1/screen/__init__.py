try:
    from screen.str_util import *
except ImportError:
    from screen.old_str_util import *
