======
screen
======

Screen width and so on

Installation
============

::

    pip install screen


Usage
=====

::

    import screen

    screen.calc_width(u'测试',0, 2)


