# -*- coding: utf-8 -*-

from django_admin.djadmin import (AddOnlyModelAdmin, AdvancedActionsModelAdmin, AdvancedExportExcelModelAdmin,
                                  ChangeOnlyModelAdmin, DeleteModelAdmin, DeleteonlyModelAdmin, DeleteOnlyModelAdmin,
                                  ExportExcelModelAdmin, Readonly2ModelAdmin, ReadonlyModelAdmin, ReadOnlyModelAdmin,
                                  SpecifiedQuantityQuerySetModelAdmin)
