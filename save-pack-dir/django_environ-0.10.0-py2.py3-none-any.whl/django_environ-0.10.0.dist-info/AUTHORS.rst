Credits
=======

``django-environ`` was initially created by `Daniele Faraglia <https://github.com/joke2k>`_
and currently maintained by `Serghei Iakovlev <https://github.com/sergeyklay/>`_.

A full list of contributors can be found in `GitHub <https://github.com/joke2k/django-environ/graphs/contributors>`__.

Acknowledgments
===============

The existence of ``django-environ`` would have been impossible without these
projects:

- `rconradharris/envparse <https://github.com/rconradharris/envparse>`_
- `jazzband/dj-database-url <https://github.com/jazzband/dj-database-url>`_
- `migonzalvar/dj-email-url <https://github.com/migonzalvar/dj-email-url>`_
- `ghickman/django-cache-url <https://github.com/ghickman/django-cache-url>`_
- `dstufft/dj-search-url <https://github.com/dstufft/dj-search-url>`_
- `julianwachholz/dj-config-url <https://github.com/julianwachholz/dj-config-url>`_
- `nickstenning/honcho <https://github.com/nickstenning/honcho>`_
- `rconradharris/envparse <https://github.com/rconradharris/envparse>`_
