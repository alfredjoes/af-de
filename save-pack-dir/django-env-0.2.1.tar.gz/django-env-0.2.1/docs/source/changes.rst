Changes
=======

0.2

 - easier setup
 - added several options to 'settings.py'
 - it should work!

0.1 - init

