
.. toctree::
    :maxdepth: 2

    readme
    settings
    code
    changes


