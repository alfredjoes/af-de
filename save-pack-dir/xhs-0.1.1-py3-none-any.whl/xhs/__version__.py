#        .__
# ___  __|  |__   ______
# \  \/  /  |  \ /  ___/
#  >    <|   Y  \\___ \
# /__/\_ \___|  /____  >
#       \/    \/     \/

__title__ = "xhs"
__description__ = "xiaohongshu crawl sdk."
__url__ = "https://github.com/ReaJason/xhs"
__version__ = "0.1.1"
__build__ = 0x000001
__author__ = "ReaJason"
__author_email__ = "reajason1225@gmail.com"
__license__ = "MIT"
__copyright__ = "Copyright ReaJason"
__cake__ = "\u2728 \U0001F370 \u2728"
