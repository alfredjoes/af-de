from requests import RequestException


class DataFetchError(RequestException):
    """"""
