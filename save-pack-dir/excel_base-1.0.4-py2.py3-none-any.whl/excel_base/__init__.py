# -*- coding: utf-8 -*-

from excel_base.compat import *
from excel_base.excel import (LeftMergeCell, MergeCell, UpMergeCell, as_csv, as_dict_row_merge_xls,
                              as_list_row_merge_xls, as_row_merge_xls, as_xls, use_xls_or_not)
